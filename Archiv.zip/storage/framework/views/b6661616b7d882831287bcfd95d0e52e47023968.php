<!doctype html>
<html lang="cz">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <!-- CSRF Token -->
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

        <title><?php echo e(config('app.name', 'Laravel')); ?></title>

        <!-- Fonts -->
        <link rel="dns-prefetch" href="//fonts.gstatic.com">

        <!-- Bootstrap dependencies -->
        <!-- Bootstrap JavaScript -->
        <script src="https://code.jquery.com/jquery-3.1.0.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
        <!-- Bootstrap CSS -->
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
        <!-- Google icons -->
        <link href="https://fonts.googleapis.com/css?family=Material+Icons|Material+Icons+Outlined|Material+Icons+Two+Tone|Material+Icons+Round|Material+Icons+Sharp" rel="stylesheet">
        <!-- Default font link. -->
        <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto">
        <!--Register js script-->
        <script src="<?php echo e(asset('js/register.js')); ?>" defer></script>
        <!--Auction js script-->
        <script src="<?php echo e(asset('js/auction-scripts.js')); ?>" defer></script>
        <!-- Navbar styles -->
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/auction_style.css')); ?>">
        <!-- Register form styles -->
        <link href="<?php echo e(asset('css/register.css')); ?>" rel="stylesheet">

        <title>Aukce</title>
    </head>
<body>
    <div id="app">
        <?php $__env->startComponent('components.navbar'); ?>
        <?php if (isset($__componentOriginalfbb67f1e1089894701a2681a454eed261a531a36)): ?>
<?php $component = $__componentOriginalfbb67f1e1089894701a2681a454eed261a531a36; ?>
<?php unset($__componentOriginalfbb67f1e1089894701a2681a454eed261a531a36); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
        <main class="py-4 mt-5 pt-5">
            <?php echo $__env->yieldContent('content'); ?>
        </main>
    </div>
</body>
</html>
<?php /**PATH /Users/simonstrycek/Documents/School/IIS/iis-project/resources/views/layouts/app.blade.php ENDPATH**/ ?>