<?php $__env->startSection('content'); ?>

<div class="background-grey">
    <div class="container">
      <h1><?php echo e($auction->auctionItem->item_name); ?></h1>
      <div class="d-md-flex flex-md-row two-columns align-items-stretch py-3">
        <div class="img-auction-detail mb-1 d-flex align-items-center justify-content-center">
          <img class="img-fluid" src="<?php echo e(asset('storage/images/'.$auction->auctionItem->image)); ?>" alt="Položka aukce">
        </div>
        <div class="auction-detail-panel">
          <h4 id="startTime"></h4>
          <h5 id="priceName"></h5>
          <div class="d-flex align-items-top flex-wrap" id="detailPrice">
          </div>
          <div class="d-flex">
            <?php if(auth()->guard()->check()): ?>
              <?php if($registered !== 2): ?>
                <?php if($registered == 1): ?>
                  <input type="number"  class="form-control font-size-25" value="10" min="'.$bidMin.'" max="'.$bidMax.'" id="inputBid" oninput="checkBidRange()" disabled/>
                  <button class="btn btn-success ml-3" href="#" id="btnBid" role="button" onclick="makeBid()" disabled>
                    <div class="d-flex align-items-center">
                      <span class="material-icons-outlined md-36">done</span>
                      Přihodit
                    </div>  
                  </button>
                <?php else: ?>
                  <a class="btn btn-success btn-block btn-lg" href="<?php echo e(route('registerToAuction', ['id' => $auction->id])); ?>" id="btnRegister" role="button">Registrovat</a> 
                <?php endif; ?>
              <?php endif; ?>
            <?php else: ?>
              <a class="btn btn-success btn-block btn-lg" href="<?php echo e(route('login')); ?>" id="btnRegister" role="button">Registrovat</a> 
            <?php endif; ?>         
          </div>
          <span id="wrongRangeSpan" ></span>
        </div>
      </div>

    </div>
    <div class="auction-description">
      <div class="container ">
        <?php echo e($auction->auctionItem->description); ?>

      </div>
    </div>
    </div>

  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script type= "text/javascript">
    $(document).ready(function() {
      startTimer(new Date("<?php echo e($auction->start_time); ?>"), new Date("<?php echo e($auction->time_limit); ?>"), "<?php echo e($auction->id); ?>");  
    });
  </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/simonstrycek/Documents/School/IIS/iis-project/resources/views/auction/detailed-auction.blade.php ENDPATH**/ ?>