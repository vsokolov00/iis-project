<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="d-flex jumbotron justify-content-center flex-column bg-white">
            <h2>Online aukční portál pro věci všeho druhu.<br>Každá věc má u nás svou hodnotu!</h2>

            <div class="d-flex flex-md-nowrap flex-wrap justify-content-start flex-row">
                <a class="btn btn-success nav-link m-2 col-xs-2" href="<?php echo e(route('closestAuctions')); ?>" role="button">
                    <div class="d-flex justify-content-center">
                        Nejbližší aukce
                    </div>
                </a>
                <a class="btn btn-warning nav-link m-2 col-xs-2" href="<?php echo e(route('newAuction')); ?>" role="button">
                    <div class="d-flex justify-content-center">
                        Vytvořit aukci
                    </div>
                </a>
            </div>
        </div>
    </div>
	<div class="background-grey pt-2 pb-4">
        <div class="container">
                <div class="d-flex justify-content-center py-3">
                </div>
                <div>
                    <a href="<?php echo e(route('closestAuctions')); ?>" class="lists-links">
                        <div class="d-flex">
                            <h2 class="mr-1">Nejbližší aukce</h2>
                            <span class="material-icons md-36">navigate_next</span>
                        </div>
                    </a>
                    <div class="d-flex align-items-stretch mainPage-auction-list-container">
                            <div class = "align-items-center list-arrow-left hidesLeft">
                                    <div class="material-icons-outlined md-48" id="newAuctionLeft" onclick="leftScroll('#newAuctionList')">
                                            arrow_back_ios
                                    </div>
                            </div>
                            <div class="d-flex mainPage-auction-list align-items-stretch" id="newAuctionList">
                                <?php $__currentLoopData = $auctions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $auction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php $route = route("auctionDetail", ["id" => $auction->id]) ?>
                                    <div class="mainPage-auction" onclick="window.location='<?php echo e($route); ?>'">
                                            <div class="img-container">
                                                <?php if(file_exists('storage/images/'.$auction->auctionItem->image) and $auction->auctionItem->image): ?>
                                                    <img src="<?php echo e(asset('storage/images/'.$auction->auctionItem->image)); ?>" alt="Položka aukce"/>
                                                <?php else: ?>
                                                    <img src="<?php echo e(url('/')); ?>/assets/default_image.png" alt="Položka aukce"/>
                                                <?php endif; ?>
                                            </div>
                                            <h4><?php echo e($auction->auctionItem->item_name); ?></h4>

                                            <?php if($auction->is_selling): ?>
                                                <div class="mainPage-offer">
                                                    Nabídka
                                                </div>
                                            <?php else: ?>
                                                <div class="mainPage-buy">
                                                    Poptávka
                                                </div>
                                            <?php endif; ?>

                                            <h3><?php echo e($auction->starting_price); ?> Kč</h3>
                                            <span>Začátek: <?php echo e($auction->start_time); ?></span>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                            <div class = "d-flex align-items-center list-arrow-right hidesRight">
                                    <div class="list-arrow" id="newAuctionRight" onclick="rightScroll('#newAuctionList')">
                                            <span class="material-icons-outlined md-48">arrow_forward_ios</span>
                                    </div>
                            </div>
                    </div>
            </div>
            <div class="mt-5">
                    <a href="#" class="lists-links">
                        <div class="d-flex">
                            <h2 class="mr-1">Oblíbené aukce</h2>
                            <span class="material-icons md-36">navigate_next</span>
                        </div>
                    </a>
                    <div class="d-flex align-items-stretch mainPage-auction-list-container">
                            <div class = "align-items-center list-arrow-left hidesLeft">
                                    <div class="material-icons-outlined md-48" id="newAuctionLeft" onclick="leftScroll('#favouriteAuctionList')">
                                            arrow_back_ios
                                    </div>
                            </div>
                            <div class="d-flex mainPage-auction-list" id="favouriteAuctionList">
                                    
                            </div>
                            <div class = "d-flex align-items-center list-arrow-right hidesRight">
                                    <div class="list-arrow" id="newAuctionRight" onclick="rightScroll('#favouriteAuctionList')">
                                            <span class="material-icons-outlined md-48">arrow_forward_ios</span>
                                    </div>
                            </div>
                    </div>
            </div>
        </div>
	</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/simonstrycek/Documents/School/IIS/iis-project/resources/views/home.blade.php ENDPATH**/ ?>