<?php $__env->startSection('content'); ?>
<?php //include "./navbar.html";
  $auctions = array(
    array(1, "Malovaná váza", true, true, "2021-10-21T20:25:00+02:00", 20000, 35000),
    array(2, "Iphone X", true, true, "2021-10-21T20:25:00+02:00", 10000, 13000),
    array(3, "Notebook", false, false, "2021-10-21T20:25:00+02:00", 10000, 8000),
    array(4, "Urna s babičkou", true, true, "2021-10-21T20:25:00+02:00", 60000, null),
    array(5, "Zemanův autogram", false, true, "2021-10-21T20:25:00+02:00", 5, null),
    array(6, "Oprava kapajícího kohoutku", false, false, "2021-10-21T20:25:00+02:00", 500, null)
  );
?>
<!doctype html>
<html lang="cz">
  <body>
  <div class="detail-background detail-view-hide" id="detail-background"></div>
  <div class="detail-container d-flex align-items-center justify-content-center detail-view-hide" id="detail-container">
      <div class="detail-form detail-view-hide d-flex flex-column" id="detail-form">
        <a class="ml-auto" role="button" onclick="hideDetail()">
          <span class="material-icons-outlined">close</span>
        </a>

        <table class="table-plain">
          <tr>
            <th scope="row">Název</th>
            <td>Malovaná váza</td>
          </tr>
          <tr>
            <th scope="row">Schválená</th>
            <td>afafd@afdas</td>
          </tr>
        </table>
        <div id="userAuctions" class="detail-list-view"></div>
      </div>

    </div>
    <div class="container">
      <h1>Vytvořené aukce</h1>
      <table class="table table-striped table-display-lg ">
        <thead>
          <tr>
            <th scope="col">Název</th>
            <th scope="col" class="text-center">Schválená</th>
            <th scope="col">Typ aukce</th>
            <th scope="col">Začátek aukce</th>
            <th scope="col" class="text-right">Počáteční cena</th>
            <th scope="col" class="text-right">Konečná cena</th>
          </tr>
        </thead>
        <tbody>
          <?php
          foreach($auctions as $auction){
          echo '
          <tr onclick="showDetail('.$auction[0].')">
            <td>'.$auction[1].'</td>
            <td>
              <div class="d-flex justify-content-center">';
                if($auction[2])
                  echo '<span class="material-icons-outlined green-text md-36">check</span>';
                else
                  echo '<span class="material-icons-outlined yellow-text md-36">watch_later</span>';
              echo '
              </div>
            </td>
            <td>
              <div class="d-flex justify-content-center flex-column ">
                <div class="material-switch pull-right " id="auctionTypeSwitch" onclick="checkboxChange('; echo"'#".$auction[0]."type', '#auctionTypeLabel".$auction[0]."'"; echo')">
                  <input id="'.$auction[0].'type" type="checkbox"';
                  if($auction[2])
                    echo ' disabled';

                    if($auction[3])
                        echo ' checked/>';
                    else
                        echo '/>';
                    echo '
                  <label for="'.$auction[0].'type" class="label-yellow"></label>
                </div>
                <div id="auctionTypeLabel'.$auction[0].'" class="auctionTypeLabel';
                if($auction[3])
                        echo ' label-yellow">Prodej';
                    else
                        echo ' label-green">Nákup';
                    echo '</div>
              </div>
            </td>';
            $startTime = strtotime($auction[4]);
            echo'
            <td>'.date("j. n. Y H:i", $startTime).'</td>
            <td class="text-right">'.number_format($auction[5],0,"", " ").' Kč</td>';
            if($auction[6] == null){
                echo '<td class="text-center">-</td>';
            }else{
                echo '<td class="text-right">'.number_format($auction[6],0,"", " ").' Kč</td>';
            }
          echo '</tr>';
          }
          ?>
        </tbody>
      </table>

      <table class="table table-striped table-display-sm" >
        <tbody>
          <?php
            foreach($auctions as $auction){
              echo '
                <tr onclick="showDetail('.$auction[0].')">
                  <td>
                    <table class="table-plain">
                    <tbody>
                      <tr>
                      <th scope="row">Název</th>
                      <td>'.$auction[1].'</td>
                      </tr>
                      <tr>
                        <th scope="row">Schválená</th>
                        <td>';
                            if($auction[2])
                              echo '<span class="material-icons-outlined green-text md-36">check</span>';
                            else
                              echo '<span class="material-icons-outlined yellow-text md-36">watch_later</span>';
                            echo '
                        </td>
                      </tr>
                      <tr>
                        <th scope="row">Typ aukce</th>
                        <td>
                          <div class="d-flex justify-content-center flex-column ">
                            <div class="material-switch pull-right " id="auctionTypeSwitch" onclick="checkboxChange('; echo"'#".$auction[0]."typeMob', '#auctionTypeLabelMob".$auction[0]."'"; echo')">
                              <input id="'.$auction[0].'typeMob" type="checkbox"';
                              if($auction[2])
                                echo ' disabled';

                                if($auction[3])
                                    echo ' checked/>';
                                else
                                    echo '/>';
                                echo '
                              <label for="'.$auction[0].'typeMob" class="label-yellow"></label>
                            </div>
                            <div id="auctionTypeLabelMob'.$auction[0].'" class="auctionTypeLabel';
                              if($auction[3])
                                echo ' label-yellow">Prodej';
                              else
                                echo ' label-green">Nákup';
                              echo '</div>
                          </div>
                        </td>
                      </tr>
                      <tr>
                        <th scope="row">Začátek aukce</th>';
                        $startTime = strtotime($auction[4]);
                        echo'
                        <td>'.date("j. n. Y H:i", $startTime).'</td>
                      </tr>
                      <tr>
                        <th scope="row">Počáteční cena</th>
                        <td>'.number_format($auction[5],0,"", " ").' Kč</td>
                      </tr>
                      <tr>
                        <th scope="row">Konečná cena</th>';
                        if($auction[6] == null){
                          echo '<td>-</td>';
                        }else{
                          echo '<td>'.number_format($auction[6],0,"", " ").' Kč</td>';
                        }
                        echo '</tr>
                      </tbody>
                    </table>
                  </td>
                </tr>
              ';
            }
          ?>
        </tbody>
      </table>
    </div>

  </body>
</html>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/simonstrycek/Documents/School/IIS/iis-project/resources/views/created-auctions-list.blade.php ENDPATH**/ ?>