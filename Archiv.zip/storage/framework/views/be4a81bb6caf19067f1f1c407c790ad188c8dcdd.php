<?php $__env->startSection('content'); ?>
    <div class="background-grey pt-5 pb-5" style="margin-top:-30px; margin-bottom:-30px">
			<div class="container">
				<h1><?php echo e($title); ?></h1>
				<div class="d-flex flex-wrap align-items-stretch  mainPage-auction-list" id="allAuctionsList">
					<?php $__currentLoopData = $auctions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $auction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<?php $route = route("auctionDetail", ["id" => $auction->id]) ?>
						<div class="allAuctions-item" onclick="window.location='<?php echo e($route); ?>'">
							<div class="img-container d-flex align-items-center justify-content-center">
								<div>
									<img class="img-fluid" src="<?php echo e(asset('storage/images/'.$auction->auctionItem->image)); ?>" alt="Položka aukce"/>
								</div>
							</div>
							<h4><?php echo e($auction->auctionItem->item_name); ?></h4>
							<?php if($auction->is_selling): ?>
								<div class="mainPage-offer">
									Nabídka
								</div>
							<?php else: ?>
								<div class="mainPage-buy">
									Poptávka
								</div>
							<?php endif; ?>
							<h3><?php echo e($auction->starting_price); ?> Kč</h3>
							<span>Začátek: <?php echo e($auction->start_time); ?></span>
						</div>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					<!-- divs to fill free space-->
					<div class="allAuctions-item-fill"></div>
					<div class="allAuctions-item-fill"></div>
					<div class="allAuctions-item-fill"></div>
				</div>
			</div>
		</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/simonstrycek/Documents/School/IIS/iis-project/resources/views/allAuctions.blade.php ENDPATH**/ ?>