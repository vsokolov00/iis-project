<nav class="navbar navbar-expand-lg fixed-top navbar-light bg-light" style="box-shadow: 0px 0px 5px #888888;">
    <div class="container">
        <a class="navbar-brand mr-auto" href="<?php echo e(route('home')); ?>">
            <img src="<?php echo e(url('/')); ?>/assets/logo.png" width="75" style="margin: -10px 0px -10px 0px;"/>
        </a>

        <a class="btn btn-success nav-link mx-1" href="<?php echo e(url('form')); ?>" role="button">
            <div class="d-flex align-items-center">
            <span class="material-icons-outlined">shopping_cart</span>
            <span class="d-none d-lg-block">Chci koupit</span>
            </div>
        </a>

        <a class="btn btn-warning nav-link mx-1" href="<?php echo e(url('form')); ?>" role="button">
        <div class="d-flex align-items-center">
            <span class="material-icons-outlined">sell</span>
            <span class="d-none d-lg-block">Chci prodat</span>
        </div>
        </a>
        <div class="nav-item dropdown d-none d-lg-block">
        <span id="account_circle" class="material-icons md-48 nav-link " role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">account_circle</span>
        <div class="dropdown-menu dropdown-menu-right">
            <?php if(auth()->guard()->guest()): ?>
                <?php if(Route::has('login')): ?>
                    <a class="dropdown-item" href="<?php echo e(route('login')); ?>">Přihlásit</a>
                <?php endif; ?>

                <?php if(Route::has('register')): ?>
                    <a class="dropdown-item" href="<?php echo e(route('register')); ?>">Registrovat</a>
                <?php endif; ?>
            <?php else: ?>
                <a href="<?php echo e(route('profile')); ?>" class="dropdown-item"><h4><?php echo e(Auth::user()->name); ?></h4></a>
                <a class="dropdown-item" href="#">Moje nabídky</a>
                <a class="dropdown-item" href="#">Registrované aukce</a>
                <a class="dropdown-item" href="#">Nastavení</a>
                <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                            onclick="event.preventDefault();
                            document.getElementById('logout-form').submit()">
                            Odhlásit se
                </a>

                <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                    <?php echo csrf_field(); ?>
                </form>

                <div class="dropdown-divider"></div>
            <?php endif; ?>
        </div>
        </div>

        <div class=" nav-link mx-1 d-lg-none">
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        </div>
        <div class="d-lg-none collapse navbar-collapse" id="navbarSupportedContent">
        <?php if(auth()->guard()->guest()): ?>
            <div class="list-group d-lg-none">
                <?php if(Route::has('login')): ?>
                    <a class="list-group-item list-group-item-action" href="<?php echo e(route('login')); ?>"><?php echo e(__('Login')); ?></a>
                <?php endif; ?>

                <?php if(Route::has('register')): ?>
                    <a class="list-group-item list-group-item-action" href="<?php echo e(route('register')); ?>"><?php echo e(__('Register')); ?></a>
                <?php endif; ?>
            </div>
        <?php else: ?>
            <h4 class="d-lg-none" ><?php echo e(Auth::user()->name); ?></h4>

            <div class="list-group d-lg-none">
                <a href="#" class="list-group-item list-group-item-action">Moje nabídky</a>
                <a href="#" class="list-group-item list-group-item-action">Registrované aukce</a>
                <a href="#" class="list-group-item list-group-item-action">Nastavení</a>
                <a class="list-group-item list-group-item-action" href="<?php echo e(route('logout')); ?>"
                        onclick="event.preventDefault();
                                        document.getElementById('logout-form').submit();">
                        Odhlásit se
                </a>

                <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                    <?php echo csrf_field(); ?>
                </form>
            </div>
        <?php endif; ?>
        </div>
    </div>
</nav>
<?php /**PATH /Users/simonstrycek/Documents/School/IIS/iis-project/resources/views/components/navbar.blade.php ENDPATH**/ ?>