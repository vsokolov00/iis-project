<!-- Fonts -->
<link rel="dns-prefetch" href="//fonts.gstatic.com">

<!-- Bootstrap CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
<!-- Default font link. -->
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto">

<!-- Navbar styles -->
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/auction_style.css')); ?>">
<!-- Register form styles -->
<link href="<?php echo e(asset('css/register.css')); ?>" rel="stylesheet">

<?php if(isset($price) && isset($lastBid)): ?>
    <div class="yellow-text"><?php echo e($price); ?></div>
    <div class="green-text"><?php echo e($lastBid); ?></div>
<?php else: ?> if(isset($price))
    <div class="yellow-text"><?php echo e($price); ?></div>
<?php endif; ?>
<?php /**PATH /Users/simonstrycek/Documents/School/IIS/iis-project/resources/views/components/price.blade.php ENDPATH**/ ?>