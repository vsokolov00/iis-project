<?php $__env->startSection('content'); ?>
	<div class="container">
		<h1>Vytvořené aukce</h1>
		<table class="table table-striped table-display-lg ">
			<thead>
				<tr>
					<th scope="col">Název</th>
					<th scope="col" class="text-center">Schválená</th>
					<th scope="col">Typ aukce</th>
					<th scope="col">Začátek aukce</th>
					<th scope="col" class="text-right">Počáteční cena</th>
					<th scope="col" class="text-right">Konečná cena</th>
				</tr>
			</thead>
			<tbody>
                <?php $imagePath = "storage/images/"; ?>
				<?php $__currentLoopData = $auctions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $auction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr onclick="openModal('<?php echo e($auction->id); ?>', '<?php echo e(asset($imagePath . $auction->auctionItem->image)); ?>', '<?php echo e($auction->auctionItem->item_name); ?>', `<?php echo e($auction->auctionItem->description); ?>`,
                        '<?php echo e($auction->starting_price); ?>', '<?php echo e($auction->bid_min); ?>', '<?php echo e($auction->bid_max); ?>', '<?php echo e($auction->start_time); ?>', '<?php echo e($auction->time_limit); ?>', '<?php echo e($auction->is_open); ?>', '<?php echo e($auction->is_selling); ?>')">
                            <td><?php echo e($auction->auctionItem->item_name); ?></td>
                            <td>
                                <div class="d-flex justify-content-center">
                                    <?php if($auction->is_approved): ?>
                                        <span class="material-icons-outlined green-text md-36">check</span>
                                    <?php else: ?>
                                        <span class="material-icons-outlined yellow-text md-36">watch_later</span>
                                    <?php endif; ?>
                                </div>
                            </td>
                            <td>
                                    <?php if($auction->is_selling): ?>
                                        <div class="auctionTypeLabel label-yellow">Prodej</div>
                                    <?php else: ?>
                                        <div class="auctionTypeLabel label-green">Nákup</div>
                                    <?php endif; ?>
                            </td>
                            <td>
                                    <?php echo e(date("j. n. Y H:i", strtotime($auction->start_time))); ?>

                            </td>
                            <td class="text-right">
                                <?php echo e(number_format($auction->starting_price,0,"", " ")); ?> Kč
                            </td>
                            <?php if($auction->closing_price == null): ?>
                                <td class="text-center">-</td>
                            <?php else: ?>
                                <td class="text-right">
                                        <?php echo e(number_format($auction->closing_price ,0 ,"", " ")); ?>	Kč
                                </td>
                            <?php endif; ?>
                        </tr>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</tbody>
			</table>

			<table class="table table-striped table-display-sm" >
				<tbody>
					<?php $__currentLoopData = $auctions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $auction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td onclick="openModal('<?php echo e($auction->id); ?>', '<?php echo e(asset($imagePath . $auction->auctionItem->image)); ?>', '<?php echo e($auction->auctionItem->item_name); ?>', `<?php echo e($auction->auctionItem->description); ?>`,
                                '<?php echo e($auction->starting_price); ?>', '<?php echo e($auction->bid_min); ?>', '<?php echo e($auction->bid_max); ?>', '<?php echo e($auction->start_time); ?>', '<?php echo e($auction->time_limit); ?>', '<?php echo e($auction->is_open); ?>', '<?php echo e($auction->is_selling); ?>')">
                                <table class="table-plain">
                                    <tbody>
                                        <tr>
                                        <th scope="row">Název</th>
                                        <td><?php echo e($auction->auctionItem->item_name); ?></td>
                                        </tr>
                                        <tr>
                                            <th scope="row">Schválená</th>
                                            <td>
                                                    <?php if($auction->is_approved): ?>
                                                        <span class="material-icons-outlined green-text md-36">check</span>
                                                    <?php else: ?>
                                                        <span class="material-icons-outlined yellow-text md-36">watch_later</span>
                                                    <?php endif; ?>
                                            </td>
                                        </tr>
                                        <tr>
                                            <th scope="row">Typ aukce</th>
                                            <td>
                                                <?php if($auction->is_selling): ?>
                                                    <div class="auctionTypeLabel label-yellow">Prodej</div>
                                                <?php else: ?>
                                                    <div class="auctionTypeLabel label-green">Nákup</div>
                                                <?php endif; ?>
                                            </td>
                                        </tr>
                                        <tr>
                                            <th scope="row">Začátek aukce</th>
                                            <td>
                                                <?php echo e(date("j. n. Y H:i", strtotime($auction->start_time))); ?>

                                            </td>
                                        </tr>
                                        <tr>
                                            <th scope="row">Počáteční cena</th>
                                            <td><?php echo e(number_format($auction->starting_price,0,"", " ")); ?> Kč</td>
                                        </tr>
                                        <tr>
                                            <th scope="row">Konečná cena</th>
                                            <?php if($auction->closing_price == null): ?>
                                                <td class="text-center">-</td>
                                            <?php else: ?>
                                                <td>
                                                    <?php echo e(number_format($auction->closing_price ,0 ,"", " ")); ?>	Kč
                                                </td>
                                            <?php endif; ?>
                                        </tr>
                                    </tbody>
                                </table>
                            </td>
                        </tr>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</tbody>
		</table>
	</div>
    <?php $__env->startComponent('components/edit-auction'); ?>
    <?php if (isset($__componentOriginal8e7f97f9082e0e79888f25c32a3733c9d19ff2f7)): ?>
<?php $component = $__componentOriginal8e7f97f9082e0e79888f25c32a3733c9d19ff2f7; ?>
<?php unset($__componentOriginal8e7f97f9082e0e79888f25c32a3733c9d19ff2f7); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/simonstrycek/Documents/School/IIS/iis-project/resources/views/user/userAuctions.blade.php ENDPATH**/ ?>