<?php $__env->startSection('content'); ?>


<div class="detail-background detail-view-hide" id="detail-background"></div>
  <div class="detail-container d-flex align-items-center justify-content-center detail-view-hide" id="detail-container">
      <div class="detail-form detail-view-hide d-flex flex-column" id="detail-form">
        <a class="ml-auto" onclick="hideDetail()">
          <span class="material-icons-outlined">close</span>
        </a>

        <table class="table-plain">
          <tr>
            <th scope="row">Jméno</th>
            <td id="detailUserName">Matěj Gotzman</td>
          </tr>
          <tr>
            <th id="detailUserEmail" scope="row">Email </th>
            <td>afafd@afdas</td>
          </tr>
        </table>
        <div id="userAuctions" class="detail-list-view"></div>
      </div>

    </div>
    <div class="container">
      <h1>Seznam uživatelů</h1>
      <table class="table table-striped table-display-lg ">
        <thead>
          <tr>
            <th scope="col">Jméno</th>
            <th scope="col">Liciátor</th>
            <th scope="col">Administrátor</th>
          </tr>
        </thead>
        <tbody>
          <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr onclick="openUserModal('<?php echo e($user->id); ?>', '<?php echo e($user->name); ?>', '<?php echo e($user->email); ?>')">
            <td><?php echo e($user->name); ?></td>
            <td>
              <div class="material-switch pull-right">
                <input class="role type-toggle" id="<?php echo e($user->id); ?>rlic"  type="checkbox" name="roleLic" data-userid="<?php echo e($user->id); ?>" data-role="auctioneer"
                <?php if($user->is_auctioneer()): ?> checked <?php endif; ?> />
              <label for="<?php echo e($user->id); ?>rlic" class="label-green"></label>
              </div>
            </td>
            <td>
              <div class="material-switch pull-right">
                <input class="role type-toggle" id="<?php echo e($user->id); ?>radmin" type="checkbox" name="roleAdm" data-userid="<?php echo e($user->id); ?>" data-role="admin"
                <?php if($user->is_admin()): ?> checked <?php endif; ?> />
              <label for="<?php echo e($user->id); ?>radmin" class="label-yellow"></label>
              </div>
            </td>
          </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
      </table>

      <table class="table table-striped table-display-sm" >
      <tbody>
            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
             <tr onclick="showDetail(<?php echo e($user->id); ?>)">
                <td>
                <table class="table-plain">
                <tbody>
                    <tr>
                      <th scope="row">Jméno </th>
                      <td><?php echo e($user->name); ?></td>
                    </tr>
                      <tr>
                        <th scope="row">Liciátor</th>
                        <td>
                            <div class="material-switch pull-right mrole">
                              <input class="mrole type-toggle" id="<?php echo e($user->id); ?>rlic-m" type="checkbox" name="roleLic" data-userid="<?php echo e($user->id); ?>" data-role="auctioneer"
                              <?php if($user->is_auctioneer()): ?> checked <?php endif; ?> />
                            <label for="<?php echo e($user->id); ?>rlic-m" class="label-green"></label>
                            </div>
                        </td>
                      </tr>
                      <tr>
                        <th scope="row">Administrátor</th>
                        <td>
                            <div class="material-switch pull-right mrole">
                                <input class="mrole type-toggle" id="<?php echo e($user->id); ?>radmin-m" type="checkbox" name="roleAdm" data-userid="<?php echo e($user->id); ?>" data-role="admin"
                                <?php if($user->is_admin()): ?> checked <?php endif; ?> />
                              <label for="<?php echo e($user->id); ?>radmin-m" class="label-yellow"></label>
                            </div>
                        </td>
                      </tr>
                      </tbody>
                    </table>
                  </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
      </table>
    </div>
    <?php $__env->startComponent('components/edit-user'); ?>
    <?php if (isset($__componentOriginalda4bbef1c3ed1d0630cbd3dfe5cce8ab5ccad5f9)): ?>
<?php $component = $__componentOriginalda4bbef1c3ed1d0630cbd3dfe5cce8ab5ccad5f9; ?>
<?php unset($__componentOriginalda4bbef1c3ed1d0630cbd3dfe5cce8ab5ccad5f9); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/simonstrycek/Documents/School/IIS/iis-project/resources/views/user/userList.blade.php ENDPATH**/ ?>