<?php $__env->startSection('content'); ?>
<div class="container page login-page">
    <div class="jumbotron-fluid">

        <h1 id="login-header">Přihlášení</h1>

        <form method="POST" id="loginForm" name="loginForm">
            <?php echo csrf_field(); ?>
            <div class="input-group col-lg-5 col-xs-5">
                <div class="login">
                    <input id="login-username" type="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> text-input" name="email" value="<?php echo e(old('email')); ?>" required autocomplete="email" autofocus placeholder="E-mailová adresa">
                        <i class="material-icons form-icon">person</i>
                    </input>
                </div>
                <b class="err-label" id="invalid-username">
                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <?php echo e($message); ?>

                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </b>
            </div>

            <div class="input-group col-lg-5 col-xs-5">
                <div class="login">
                    <input id="login-password" type="password" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> text-input" name="password" required autocomplete="current-password" placeholder="Heslo">
                        <a href="#" class="form-icon"><i id="eyeIcon" class="material-icons">visibility_off</i></a>
                    </input>
                </div>
                <b class="err-label" id="invalid-password">
                    <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <?php echo e($message); ?>

                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </b>
            </div>

            <div class="input-group col-7 col-lg-4">
                <button type="submit" class="btn btn-primary button-yellow btn-group-lg btn-block">Přihlásit</button>
            </div>

            <div class="col-lg-5 col-xs-5">
                <?php if(Route::has('register')): ?>
                    <center>
                        <a href="<?php echo e(route('register')); ?>">Nemáte účet? Registrujte se u nás!</a>
                    </center>
                <?php endif; ?>
            </div>
        </form>
    </div>
</div>
</div>

<script>
    $(document).ready(function() {
        $("#eyeIcon").click(function (event) {
            if($("#password").attr("type") == "password")
            {
                $("#password").attr("type", "text");
                $("#eyeIcon").text("visibility");
            }
            else
            {
                $("#password").attr("type", "password");
                $("#eyeIcon").text("visibility_off");
            }
        });
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/simonstrycek/Documents/School/IIS/iis-project/resources/views/auth/login.blade.php ENDPATH**/ ?>