# iis-project
Task variant - 4. Aukce: prodej a nákup zboží a majetku prostřednictvím dražby
